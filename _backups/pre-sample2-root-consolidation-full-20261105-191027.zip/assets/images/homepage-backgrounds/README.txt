INDIAN RESTAURANT WEBSITE — SECTION BACKGROUNDS

14 individual background images cropped from the generated decorative background sheet.
Use CSS background-size: cover; background-position: center; and add a subtle overlay behind text when needed.

01_hero_banquet_lanterns.webp
01_location_palace_parchment.webp
02_green_lotus_mandala.webp
02_maroon_lotus_mandala.webp
03_cream_palace_archway.webp
03_green_palace_skyline.webp
04_cream_lotus_parchment.webp
04_green_banana_leaves.webp
05_green_lantern_palace.webp
05_cream_palace_mandala.webp
06_maroon_gold_lotus.webp
06_green_food_biryani.webp
07_cream_heritage_courtyard.webp
07_green_mandala_footer.webp

Suggested use:
- Hero: 01_hero_banquet_lanterns.webp
- Location / intro: 01_location_palace_parchment.webp or 03_cream_palace_archway.webp
- Green feature sections: 02_green_lotus_mandala.webp, 04_green_banana_leaves.webp, 05_green_lantern_palace.webp
- Maroon feature sections: 02_maroon_lotus_mandala.webp, 06_maroon_gold_lotus.webp
- Specials / food: 06_green_food_biryani.webp
- Catering / heritage: 07_cream_heritage_courtyard.webp
- Footer: 07_green_mandala_footer.webp
